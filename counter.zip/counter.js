let counter = () => {
    for(let i = 0; i < 1000; i++) {
        console.log(i);
    }
}

//counter();